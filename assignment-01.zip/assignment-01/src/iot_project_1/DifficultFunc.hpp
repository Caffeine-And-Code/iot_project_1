#ifndef DIFFICULT_FUNC_H
#define DIFFICULT_FUNC_H

void setDifficult(int value);

int getDifficult();

int getMillisecondsBasedByScore(int score);

#endif