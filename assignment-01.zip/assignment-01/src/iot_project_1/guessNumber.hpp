#ifndef GUESS_NUMBER
#define GUESS_NUMBER

int generateNumber();
int getCurrentNumber();
bool checkBinary(bool b3, bool b2, bool b1, bool b0);

#endif GUESS_NUMBER